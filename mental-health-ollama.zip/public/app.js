
const chat = document.getElementById('chat');
const form = document.getElementById('inputForm');
const promptInput = document.getElementById('prompt');
const quick = document.querySelectorAll('.quick-tags button');

let history = [
  {role:'system', content:"You are CalmLeaf — a gentle, empathetic mental health assistant. Always be supportive, avoid giving medical diagnosis, encourage seeking professional help when needed. When user expresses self-harm or emergency direct them to emergency services and provide crisis hotlines."}
];

function appendBot(text){
  const el = document.createElement('div');
  el.className = 'bot-bubble';
  el.innerHTML = `<div class="avatar">🌿</div><div class="text">${escapeHtml(text)}</div>`;
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
}
function appendUser(text){
  const el = document.createElement('div');
  el.className = 'user-bubble';
  el.innerHTML = `<div class="text">${escapeHtml(text)}</div>`;
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
}
function escapeHtml(s){ return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;'); }

quick.forEach(b=>{
  b.addEventListener('click', ()=> {
    const tag = b.dataset.tag;
    promptInput.value = tag;
    form.requestSubmit();
  });
});

form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const text = promptInput.value.trim();
  if(!text) return;
  appendUser(text);
  history.push({role:'user', content:text});
  promptInput.value='';
  appendBot('...');

  try {
    const r = await fetch('/api/generate', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ messages: history })
    });
    const json = await r.json();
    const reply = json.reply || (json.error ? 'Sorry, an error occurred.' : 'No response.');
    // remove the placeholder '...'
    const placeholders = chat.querySelectorAll('.bot-bubble');
    if(placeholders.length) placeholders[placeholders.length-1].remove();
    appendBot(reply);
    history.push({role:'assistant', content:reply});
  } catch (err) {
    console.error(err);
    appendBot('Network error. Try again later.');
  }
});
